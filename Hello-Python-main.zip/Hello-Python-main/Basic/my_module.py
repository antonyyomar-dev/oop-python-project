# Clase en vídeo: https://youtu.be/Kp4Mvapo5kc?t=34583

### Módulo para pruebas ###

def sumValue(numberOne, numberTwo, numberThree):
    print(numberOne + numberTwo + numberThree)


def printValue(value):
    print(value)
